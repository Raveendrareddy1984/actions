## Step 1 — Print a message
Run the following command in the terminal:
```bash
echo "Hello from Killercoda!"
```
If you see the text above, your scenario is wired up correctly.
