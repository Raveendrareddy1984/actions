# Hello World (Single Step)
This tiny scenario checks that your Killercoda setup is working.
You'll run a simple command in the terminal.
