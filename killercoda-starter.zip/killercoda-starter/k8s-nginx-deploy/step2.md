## Step 2 — Expose as a Service
```bash
kubectl expose deployment web --port=80 --target-port=80 --name=web-svc
kubectl get svc web-svc -o wide
```
