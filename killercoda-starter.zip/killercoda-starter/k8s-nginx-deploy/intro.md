# Kubernetes: Deploy NGINX
In this scenario you'll:
- Create a Deployment
- Expose it as a Service
- Validate the response
