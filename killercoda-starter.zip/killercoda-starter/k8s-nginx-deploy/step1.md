## Step 1 — Create a Deployment
Apply the following manifest:
```bash
cat <<'EOF' > nginx-deploy.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
spec:
  replicas: 2
  selector:
    matchLabels:
      app: web
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
      - name: nginx
        image: nginx:1.25
        ports:
        - containerPort: 80
EOF
kubectl apply -f nginx-deploy.yaml
kubectl rollout status deploy/web
```
