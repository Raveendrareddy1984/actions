## Step 3 — Test the Service
Port-forward locally and curl:
```bash
kubectl port-forward svc/web-svc 8080:80 > /tmp/pf.log 2>&1 &
sleep 1
curl -i http://127.0.0.1:8080/ | head -n 5
```
